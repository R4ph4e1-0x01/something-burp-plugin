#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2019/7/26 10:13 AM
# @Author  : w8ay
# @File    : __init__.py.py

REPOSITORY = "https://github.com/boy-hack/w13scan.git"

VERSION = '0.9.17'
