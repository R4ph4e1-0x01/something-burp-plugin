#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# @Time    : 2019/6/28 12:47 PM
# @Author  : w8ay
# @File    : data.py

from W13SCAN.lib.datatype import _ThreaData
from W13SCAN.lib.log import LOGGER


logger = LOGGER
PATH = dict()  # 全局路径
KB = dict()
Share = _ThreaData()
conf = dict()
