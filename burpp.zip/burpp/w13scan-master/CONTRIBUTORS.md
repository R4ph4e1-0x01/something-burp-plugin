## Contributors
boy-hack <https://github.com/boy-hack>
* for contributing core code

Go0p <https://github.com/Go0p>
* 加入struts系列检测插件

hackxx <https://github.com/hackxx>
* 贡献logout不扫描规则

## Other

- https://github.com/qiyeboy/BaseProxy  代理框架基于它
- https://github.com/chaitin/xray  灵感来源，部分规则基于它
- https://github.com/knownsec/pocsuite3  代码框架模仿自它
- https://github.com/lijiejie/BBScan 很多规则思路都是参考它
- 感谢大菜鸟后援团提供的帮助(P喵呜-PHPoop、ch1st、xiaoshi)